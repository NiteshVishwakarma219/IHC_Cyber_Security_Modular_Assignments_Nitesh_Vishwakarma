\
# Optional conservative scan of this computer only (localhost).
# Requires Nmap to be installed and nmap.exe available on PATH.
$nmap = Get-Command nmap -ErrorAction SilentlyContinue
if (-not $nmap) {
    Write-Error "Nmap was not found on PATH. Install Nmap from its official site or skip this optional step."
    exit 1
}
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$outDir = Join-Path $PSScriptRoot "..\evidence\nmap_$stamp"
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$outFile = Join-Path $outDir "localhost_scan.txt"
Write-Host "Scanning only 127.0.0.1 (this computer)."
& $nmap.Source -sT -sV --top-ports 20 --reason -oN $outFile 127.0.0.1
Write-Host "Saved actual Nmap output to: $((Resolve-Path $outFile).Path)"
Write-Host "Capture a screenshot showing the command and result."
