"""Analyze an educational synthetic network-flow CSV.
This script does not inspect live traffic and is not a real incident detector.
Run from the project root: python scripts/analyze_flows.py
"""
from pathlib import Path
import csv
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
src = ROOT / "data" / "educational_synthetic_flows.csv"
out_csv = ROOT / "evidence" / "synthetic_analysis_results.csv"
out_txt = ROOT / "evidence" / "synthetic_analysis_summary.txt"

with src.open(newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))

def as_float(row, key):
    return float(row[key])

results = []
for row in rows:
    pps = as_float(row, "packets_per_second")
    syn = as_float(row, "syn_ratio")
    ports = int(row["distinct_dest_ports"])
    flags = []
    if pps >= 300 and syn >= 0.80:
        flags.append("high_packet_rate_and_syn_ratio_demo")
    if ports >= 10:
        flags.append("many_destination_ports_demo")
    if pps <= 5 and float(row["duration_seconds"]) >= 120:
        flags.append("low_rate_long_duration_possible_beacon_demo")
    results.append({**row, "heuristic_flags": ";".join(flags) if flags else "none"})

out_csv.parent.mkdir(parents=True, exist_ok=True)
with out_csv.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
    writer.writeheader()
    writer.writerows(results)

counts = Counter(r["label"] for r in rows)
flagged = sum(r["heuristic_flags"] != "none" for r in results)
summary = [
    "EDUCATIONAL SYNTHETIC DATASET ANALYSIS",
    "This file describes the supplied synthetic teaching data only; it is not a live capture or a real incident.",
    f"Input rows: {len(rows)}",
    f"Rows with one or more heuristic flags: {flagged}",
    "Label counts:",
]
summary.extend(f"  - {label}: {count}" for label, count in sorted(counts.items()))
summary += [
    "",
    "Interpretation:",
    "- High packet rate plus a high SYN ratio is a pattern worth investigating in a real capture, but is not proof of a SYN flood.",
    "- Many destination ports can be consistent with scanning, but benign software can also contact many ports.",
    "- Low-rate periodic flows can be consistent with beaconing, but require endpoint, DNS, destination reputation, and timing context.",
    "- The thresholds are illustrative and should not be treated as production detection rules.",
]
out_txt.write_text("\\n".join(summary) + "\\n", encoding="utf-8")
print("\\n".join(summary))
print(f"\\nDetailed results: {out_csv}")
