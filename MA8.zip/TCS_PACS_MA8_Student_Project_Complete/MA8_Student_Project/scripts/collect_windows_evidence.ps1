\
# Collect basic network observations on this Windows computer.
# This script uses benign diagnostic commands and does not scan remote ports.
$ErrorActionPreference = "Continue"
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$outDir = Join-Path $PSScriptRoot "..\evidence\collected_$stamp"
New-Item -ItemType Directory -Path $outDir -Force | Out-Null

"Collection time: $(Get-Date -Format o)" | Out-File (Join-Path $outDir "collection_info.txt")
"Computer: $env:COMPUTERNAME" | Out-File (Join-Path $outDir "collection_info.txt") -Append
"OS: $((Get-CimInstance Win32_OperatingSystem).Caption)" | Out-File (Join-Path $outDir "collection_info.txt") -Append

Write-Host "`n[1/4] Loopback ping"
ping.exe 127.0.0.1 | Tee-Object -FilePath (Join-Path $outDir "ping_loopback.txt")

Write-Host "`n[2/4] DNS lookup"
nslookup.exe google.com | Tee-Object -FilePath (Join-Path $outDir "dns_lookup_google.txt")

Write-Host "`n[3/4] Ping to public DNS name (may be blocked by network policy)"
ping.exe -n 4 google.com | Tee-Object -FilePath (Join-Path $outDir "ping_google.txt")

Write-Host "`n[4/4] Traceroute (some hops may time out)"
tracert.exe -d -h 12 -w 800 google.com | Tee-Object -FilePath (Join-Path $outDir "traceroute_google.txt")

Write-Host "`nDone. Output saved to: $((Resolve-Path $outDir).Path)"
Write-Host "Take screenshots of the actual command outputs and add the filenames to evidence/EVIDENCE_LOG_TEMPLATE.md."
