# Practical evidence log — fill with your own observations

Student: Nitesh Vishwakarma  
Project: TCS iON PACS MA8 — Modern Network Threats and Countermeasures

| Evidence ID | Requirement | Filename | Date/time | Actual observation | Status |
|---|---|---|---|---|---|
| E1 | Loopback ping | [add screenshot/log] | [fill] | [describe packet loss/latency] | Pending |
| E2 | DNS and external ping | [add screenshot/log] | [fill] | [describe actual result; mention if blocked] | Pending |
| E3 | Traceroute | [add screenshot/log] | [fill] | [describe hops/timeouts without guessing] | Pending |
| E4 | Nmap localhost scan | [add screenshot/log] | [fill] | [describe actual open/closed/filtered results] | Pending |
| E5 | Wireshark capture | [add screenshot/pcap] | [fill] | [interface, filter, packets observed] | Pending |
| E6 | tcpdump or justified alternative | [add screenshot/log] | [fill] | [describe actual output or tool limitation] | Pending |
| E7 | Attack-pattern analysis | [dataset/source + results] | [fill] | [state whether synthetic, public sample, or own lab] | Pending |
| E8 | VPN/firewall evaluation | [policy screenshot or research notes] | [fill] | [what setting/control was evaluated] | Pending |
| E9 | Synthetic-flow script | `evidence/synthetic_analysis_summary.txt` | [run date] | Educational synthetic data only | Included after running |

