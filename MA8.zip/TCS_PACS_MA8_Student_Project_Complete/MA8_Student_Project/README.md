# TCS iON PACS — Modular Assignment 8
## Modern Network Threats and Countermeasures

**Student:** Nitesh Vishwakarma  
**Project type:** Network security assessment and defensive analysis  
**Environment:** Windows 11

## What is included
- `report/MA8_Project_Report.pdf` — report draft with threat model, attack analysis, defenses, methods, and appendices.
- `scripts/collect_windows_evidence.ps1` — collects local ping, DNS, and traceroute observations into timestamped files.
- `scripts/authorized_local_nmap.ps1` — optional conservative scan of localhost; requires Nmap.
- `scripts/analyze_flows.py` — analyzes the included clearly labelled educational synthetic dataset.
- `data/educational_synthetic_flows.csv` — synthetic example data, not real captured network traffic.
- `evidence/EVIDENCE_LOG_TEMPLATE.md` — fill with your own evidence filenames and observations.
- `docs/WIRESHARK_TCPDUMP_STEPS.md` — packet-capture steps and suggested filters.

## Important evidence note
The report distinguishes background research, synthetic demonstration data, and observations that must be collected on your own system. Do not describe synthetic data as real traffic. Run the practical scripts, save your genuine outputs/screenshots, and update the evidence log and report findings before submission.

## How to start
1. Extract the ZIP.
2. Open PowerShell in the extracted folder.
3. Run: `Set-ExecutionPolicy -Scope Process Bypass`
4. Run: `.\scripts\collect_windows_evidence.ps1`
5. Review the output folder path printed by the script
6. If Nmap is installed, run: `.\scriptsuthorized_local_nmap.ps1`
7. Follow `docs/WIRESHARK_TCPDUMP_STEPS.md` for packet capture on your own computer.
8. Replace all pending evidence entries with your real filenames and observations.

