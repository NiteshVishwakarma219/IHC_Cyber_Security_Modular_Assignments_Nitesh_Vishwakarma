# Wireshark and tcpdump evidence steps

Use only your own computer/network or a lab where you have permission. Do not attempt to generate a denial-of-service attack.

## A. Wireshark on Windows
1. Install Wireshark from its official website. During setup, install Npcap if the installer offers it and you need live capture.
2. Open Wireshark and select the active interface (Wi-Fi or Ethernet) with packet activity.
3. Start capture. Browse to a familiar website or run `nslookup example.com` in a separate terminal for a small amount of normal traffic.
4. Stop capture after roughly 30–60 seconds.
5. Save as `evidence/your_capture_name.pcapng`.
6. Try display filters:
   - `dns`
   - `tcp`
   - `tcp.flags.syn == 1 && tcp.flags.ack == 0`
   - `icmp`
7. Take a screenshot showing the capture filename, filter, packet list, and selected packet details.
8. In the report, record the date/time, interface, filter, what you observed, and limitations. Do not claim that ordinary SYN packets alone prove an attack.

## B. tcpdump (optional, Linux/WSL/lab)
On a Linux machine where tcpdump is installed, list interfaces with:
`tcpdump -D`
For a short capture on an interface you own and are authorized to monitor:
`sudo tcpdump -i <interface> -nn -c 50 -w evidence_sample.pcap`
Read the saved capture:
`tcpdump -nn -r evidence_sample.pcap`
Save terminal output and explain what was observed. Replace `<interface>` with the correct interface name. Do not run captures on networks you are not authorized to monitor.

## C. If tcpdump is not available
Do not fabricate its output. Document that it was unavailable and use Wireshark if permitted, or a provided public sample capture. If using a public capture, cite the exact source and date accessed and label it as third-party sample data.
